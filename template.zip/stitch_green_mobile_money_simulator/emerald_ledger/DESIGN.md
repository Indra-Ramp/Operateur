---
name: Emerald Ledger
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#3c4a42'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#6c7a71'
  outline-variant: '#bbcabf'
  surface-tint: '#006c49'
  primary: '#006c49'
  on-primary: '#ffffff'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#4edea3'
  secondary: '#006c4a'
  on-secondary: '#ffffff'
  secondary-container: '#82f5c1'
  on-secondary-container: '#00714e'
  tertiary: '#2b6954'
  on-tertiary: '#ffffff'
  tertiary-container: '#71af97'
  on-tertiary-container: '#004231'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#85f8c4'
  secondary-fixed-dim: '#68dba9'
  on-secondary-fixed: '#002114'
  on-secondary-fixed-variant: '#005137'
  tertiary-fixed: '#b0f0d6'
  tertiary-fixed-dim: '#95d3ba'
  on-tertiary-fixed: '#002117'
  on-tertiary-fixed-variant: '#0b513d'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  display:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  container-padding: 24px
  gutter: 16px
---

## Brand & Style
The brand personality is authoritative yet accessible, designed to evoke feelings of security, precision, and financial growth. Targeting both casual users and financial professionals, the UI balances high-utility fintech density with a modern, breathable aesthetic.

The design style is **Corporate / Modern** with a focus on high-clarity information architecture. It utilizes a layered approach where functional elements are clearly demarcated through subtle depth and high-contrast color blocking. The interface prioritizes rapid recognition of financial data through systematic spacing and a curated emerald palette that symbolizes prosperity and stability.

## Colors
The color strategy employs a "Green-Positive" scale to reinforce financial success. 
- **Primary (#10B981):** Used for primary actions, success states, and key growth indicators.
- **Secondary (#059669):** Used for hover states and active navigation elements to provide visual weight.
- **Tertiary (#064E3B):** Reserved for high-contrast text, deep backgrounds, and branding elements to ensure professional grounding.
- **Neutral:** A range of cool grays (Slate/Gray scale) provides the foundation for surfaces and borders, ensuring the green accents remain the focal point.

## Typography
**Inter** is the workhorse of this design system, chosen for its exceptional legibility in data-heavy environments. To distinguish technical data (transaction IDs, currency codes, account numbers), **JetBrains Mono** is introduced for labels and small-caps data points.

- **Headlines:** Utilize tighter letter spacing and heavier weights to create a strong hierarchy.
- **Body:** Standardized on a 14px/16px scale for optimal reading density in tables and lists.
- **Numerical Data:** Always use tabular figures (tnum) where available to ensure vertical alignment in financial columns.

## Layout & Spacing
The layout follows a **Fluid Grid** model with strict 8px incremental spacing (the "4px base" is only for micro-adjustments). 

- **Desktop:** 12-column grid with 24px gutters. Sidebars are fixed at 280px.
- **Mobile:** Single column with 16px horizontal margins. 
- **Financial Tables:** Use condensed vertical padding (8px or 12px) to maximize the amount of visible data per screen.
- **Cards:** Utilize 'lg' (24px) padding for dashboard widgets to create a premium, spacious feel.

## Elevation & Depth
Depth is signaled through **Tonal Layers** and **Ambient Shadows**. This design system avoids heavy blacks in shadows, opting for tinted semi-transparent greens to maintain the brand theme.

- **Level 0 (Background):** #F9FAFB.
- **Level 1 (Cards/Surface):** Pure White (#FFFFFF) with a 1px border (#E5E7EB) and a soft "Smoky Emerald" shadow (0 4px 6px -1px rgba(6, 78, 59, 0.05)).
- **Level 2 (Modals/Dropdowns):** Pure White with a more pronounced shadow (0 10px 15px -3px rgba(6, 78, 59, 0.1)).
- **Interactions:** Hovered states for buttons and cards should lift slightly (y-minus translation) rather than just changing color.

## Shapes
The design system uses a generous **2xl (1.0rem / 16px)** corner radius for primary containers and cards to soften the corporate tone and feel "modern-fintech." 

- **Input Fields/Buttons:** Use 12px (0.75rem) to maintain structural integrity.
- **Small Components (Chips/Badges):** Use full pill-shaped rounding for high contrast against the rectangular grid.
- **Charts:** Corner smoothing is applied to bar charts (top radius only) to match the UI shape language.

## Components
### Buttons
- **Primary:** Solid Emerald (#10B981) with White text. High-contrast shadow on hover.
- **Secondary:** White background, Emerald border, and Emerald text.
- **Tertiary/Ghost:** No border, Tertiary Green text. Use for less critical actions like "Cancel" or "View All."

### Form Inputs
- **Inputs:** 1px border-gray-300, focusing to 2px Emerald. 
- **Prefixes:** Use a light-gray background (#F3F4F6) for currency or country code dropdowns attached to the left of the input field.
- **Validation:** Errors must use Red-500 with a supporting icon for accessibility.

### Financial Tables & Cards
- **Transaction Cards:** High-contrast title (Amount) with a secondary label (Merchant/Date). Positive amounts in Primary Green; negative amounts in Text Primary.
- **Data Tables:** Zebra striping is avoided; use subtle 1px bottom borders. Headers are all-caps JetBrains Mono with 500 weight.
- **Pagination:** Simple numerical buttons with "Previous/Next" using icons. The active page should be a solid Emerald circle.

### Charts
- Use a monochromatic emerald scale for line charts. 
- Grid lines should be faint Gray-100. 
- Tooltips must use the Level 2 elevation shadow and Tertiary Green for text.